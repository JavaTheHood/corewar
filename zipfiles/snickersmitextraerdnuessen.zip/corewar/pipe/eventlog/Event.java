/* Roman Podolski - r.podolski@web.de, Janek Schoenwetter - janek.schoenwetter@yahoo.com
 * Praktikum Softwareentwicklung II, SS2011
 * Geotelematik und Navigation (GO1b), Hochschule M�nchen
 *   ____
 *  / ___|___  _ __ _____      ____ _ _ __
 * | |   / _ \| '__/ _ \ \ /\ / / _` | '__|
 * | |__| (_) | | |  __/\ V  V / (_| | |
 *  \____\___/|_|  \___| \_/\_/ \__,_|_|
 *
 * Sun Microsystems Inc. Java 1.6.0_24,
 * Windows 7 Enterprise, Windows 7 Starter
 * CANTIA-(Intel(R) Core(TM)2 Duo CPU 2.26GHz, 2267 MHz)
 * ASUS Eee PC (Intel(R) Atom(TM) CPU N550 @ 1,50 GHz)
 */
package corewar.pipe.eventlog;

import java.io.IOException;
import java.io.Writer;

import corewar.common.instruction.Instruction;
import corewar.common.instruction.Value;
import corewar.common.program.Task;
import corewar.pipe.decimalcode.Decimalcode;

/**
 * An Event in a Corewar. Possible events are EventTypes.
 * @author Roman Podolski - r.podolski@web.de, Janek Schoenwetter -
 *         janek.schoenwetter@yahoo.com
 * @version 1.0
 */
public class Event {

	/**
	 * The Type of the event.
	 */
	private final EventType eventType;
	/**
	 * The Index of the program, witch caused the event.
	 */
	private final int programmIndex;
	/**
	 * The executed instruction.
	 */
	private final Instruction instruction;
	/**
	 * The tread index.
	 */
	private final int threadIndex;
	/**
	 * The cycle witch runs.
	 */
	private final int cycle;
	/**
	 * the address of the warrior, task or instruction in the core.
	 */
	private final Value address;

	/**
	 * Custom constructor for Corewar Events.
	 * @param eventType
	 *            The type of the event.
	 * @param programmIndex
	 *            the Index of the program, witch caused the event.
	 * @param threadIndex
	 *            The Index of the task, witch caused the event.
	 * @param cycle
	 *            the cycle running.
	 * @param address
	 *            the address of the warrior, task or instruction in the core.
	 * @param instruction
	 *            the executed instruction.
	 */
	public Event(final EventType eventType, final int programmIndex,
			final int threadIndex, final int cycle, final Value address,
			final Instruction instruction) {
		this.eventType = eventType;
		this.programmIndex = programmIndex;
		this.threadIndex = threadIndex;
		this.cycle = cycle;
		this.address = address;
		this.instruction = instruction;
	}

	/**
	 * Getter for the program index.
	 * @return the programmIndex
	 */
	private int getProgrammIndex() {
		return programmIndex;
	}

	/**
	 * Getter for the event type.
	 * @return the eventType
	 */
	private EventType getEventType() {
		return eventType;
	}

	/**
	 * Getter for the Instruction.
	 * @return the instruction
	 */
	private Instruction getInstruction() {
		return instruction;
	}

	/**
	 * Getter for the task index.
	 * @return the threadIndex
	 */
	private int getThreadIndex() {
		return threadIndex;
	}

	/**
	 * Getter for the running Cycle.
	 * @return the cycle
	 */
	private int getCycle() {
		return cycle;
	}

	/**
	 * Getter for the Address.
	 * @return the address
	 */
	private Value getAddress() {
		return address;
	}

	/**
	 * Writes a Event on a writer.
	 * @param print
	 *            a writer.
	 * @throws IOException
	 *             could be caused by the writer.
	 */
	public void printEvent(final Writer print) throws IOException {
		print.append(toString());
	}

	/**
	 * Creates a execute event, parses it to a string and writes it on a writer.
	 * @param print
	 *            A writer on witch the execute event is written.
	 * @param task
	 *            the running task
	 * @param cycles
	 *            the running cycle
	 * @param instruction
	 *            the executed instruction
	 * @throws IOException
	 *             could be thrown from the writer.
	 */
	public static void printExecuteEvent(final Writer print, final Task task,
			final int cycles, final Instruction instruction) throws IOException {
		print.append(new Event(EventType.Execute, task.getParent().getIndex(),
				task.getIndex(), cycles, task.getAddress(), instruction)
				.toString());
	}
	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final String eventLog = getEventType().getPrefix()
				+ String.format("%01d%04d%06d%04d", getProgrammIndex(),
						getThreadIndex(), getCycle(), getAddress()
								.getArgumentValue())
				+ Decimalcode.encode(getInstruction());
		return eventLog;
	}
}
