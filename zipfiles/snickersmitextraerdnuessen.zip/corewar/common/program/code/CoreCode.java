/* Roman Podolski - r.podolski@web.de, Janek Schoenwetter - janek.schoenwetter@yahoo.com
 * Praktikum Softwareentwicklung II, SS2011
 * Geotelematik und Navigation (GO1b), Hochschule M�nchen
 *   ____
 *  / ___|___  _ __ _____      ____ _ _ __
 * | |   / _ \| '__/ _ \ \ /\ / / _` | '__|
 * | |__| (_) | | |  __/\ V  V / (_| | |
 *  \____\___/|_|  \___| \_/\_/ \__,_|_|
 *
 * Sun Microsystems Inc. Java 1.6.0_24,
 * Windows 7 Enterprise, Windows 7 Starter
 * CANTIA-(Intel(R) Core(TM)2 Duo CPU 2.26GHz, 2267 MHz)
 * ASUS Eee PC (Intel(R) Atom(TM) CPU N550 @ 1,50 GHz)
 */
package corewar.common.program.code;

import java.io.IOException;
import java.io.Writer;

import corewar.common.core.Core;
import corewar.common.exceptions.SyntaxErrorException;
import corewar.common.instruction.Instruction;
import corewar.common.program.Task;

/**
 * This is the Interface for CoreCodes. A CoreCode is a class what must define
 * the method execute, what executes and documents the changes witch this
 * command causes. For every RedCode command there has to be a corecode.
 * @author Roman Podolski - r.podolski@web.de, Janek Schoenwetter -
 *         janek.schoenwetter@yahoo.com
 * @version 1.0
 */
public interface CoreCode {

	/**
	 * This method executes a RedCode command.
	 * @param core
	 *            The MemoryArrayCore in witch the instructions of the Program
	 *            running are stored.
	 * @param task
	 *            The executing task.
	 * @param cycles
	 *            The cycles executed up to this point.
	 * @param instruction
	 *            The instruction executed.
	 * @param print
	 *            A writer on witch the events are written.
	 * @throws IOException
	 *             may be thrown by the writer.
	 * @throws SyntaxErrorException
	 *             a relict from the compiler - should actually never happen.
	 */
	void execute(Core core, Task task, int cycles, Instruction instruction,
			Writer print)
			throws IOException,
			SyntaxErrorException;

}
