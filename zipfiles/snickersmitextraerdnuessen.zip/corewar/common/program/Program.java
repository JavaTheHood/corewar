/* Roman Podolski - r.podolski@web.de, Janek Schoenwetter - janek.schoenwetter@yahoo.com
 * Praktikum Softwareentwicklung II, SS2011
 * Geotelematik und Navigation (GO1b), Hochschule M�nchen
 *   ____
 *  / ___|___  _ __ _____      ____ _ _ __
 * | |   / _ \| '__/ _ \ \ /\ / / _` | '__|
 * | |__| (_) | | |  __/\ V  V / (_| | |
 *  \____\___/|_|  \___| \_/\_/ \__,_|_|
 *
 * Sun Microsystems Inc. Java 1.6.0_24,
 * Windows 7 Enterprise, Windows 7 Starter
 * CANTIA-(Intel(R) Core(TM)2 Duo CPU 2.26GHz, 2267 MHz)
 * ASUS Eee PC (Intel(R) Atom(TM) CPU N550 @ 1,50 GHz)
 */
package corewar.common.program;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Queue;

import corewar.common.constants.Constants;
import corewar.common.core.Core;
import corewar.common.exceptions.SyntaxErrorException;
import corewar.common.instruction.Value;

/**
 * This is a RedCode Program. A Program nows its index and witch and how many
 * tasks it created and what task it the next to be executed.
 * @author Roman Podolski - r.podolski@web.de, Janek Schoenwetter -
 *         janek.schoenwetter@yahoo.com
 * @version 1.0
 */
public class Program {

	/**
	 * This is the Index of the Program. Its a unique number - its also used and
	 * returned by hashCode
	 */
	private final int index;

	/**
	 * In this Queue are the tasks stored.
	 */
	private final Queue<Task> queue;

	/**
	 * This is the number of tasks the Program has created.
	 */
	private int children;

	/**
	 * Custom constructor for a RedCodeProgram. A Program is a number of tasks
	 * (minimum one an maximum GlobalsMARS.CORESIZE tasks), so this constructor
	 * creates a task at the parameter 'address' in the core and stores it in
	 * the queue.
	 * @param address
	 *            The address were the program should start/were the task should
	 *            be created in the core.
	 * @param index
	 *            The index of the Program.
	 */
	public Program(final Value address, final int index) {
		queue = new ArrayDeque<Task>();
		queue.add(new Task(address, 0, this));
		children = 0;
		this.index = index;
	}

	/**
	 * Checks if the Program can still be executed. If there are no more
	 * executable tasks in the queue the program 'is dead'.
	 * @return true = program is alive and still can be executed / false =
	 *         program is not alive and can't be executed anymore.
	 */
	public boolean isAlive() {
		return !queue.isEmpty();
	}

	/**
	 * This is a getter for the address of the position of the instruction in
	 * the core, witch the program executes.
	 *
	 * @return the address of the position in the core.
	 */
	public Value getAddress() {
		assert isAlive() : "this program is still alive!";
		return getQueue().element().getAddress();

	}

	/**
	 * This is a getter for the index of the program.
	 * @return the index of the program.
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * A private getter for the queue. This getter is private, so no other
	 * classes can create new tasks for this program.
	 * @return the queue in witch the tasks of this program are stored.
	 */
	private Queue<Task> getQueue() {
		return queue;
	}

	/**
	 * Getter for the number of created tasks. This getter is private because
	 * its only used by the class program itself.
	 * @return the number of created tasks.
	 */
	private int getChildren() {
		return children;
	}

	/**
	 * Setter for the number of created tasks. This setter is private because
	 * its only used by the class program itself.
	 * @param children
	 *            the children to set
	 */
	private void setChildren(final int children) {
		this.children = children;
	}

	/**
	 * This method executes the next 'step' step of the program. It gets the
	 * next task from the queue and executes it. This is the 'main-function' of
	 * the class program.
	 * @param core
	 *            A MemoryArrayCore for a Corewar in witch instructions are
	 *            stored.
	 * @param cycles
	 *            the number of executed cycles.
	 * @param print
	 *            A writer on witch events can be written.
	 * @throws SyntaxErrorException
	 *             actually not possibly - a relict from the constructor.
	 * @throws IOException
	 *             could be caused by the writer.
	 */
	public void step(final Core core, final int cycles, final Writer print)
			throws IOException, SyntaxErrorException {
		final Task task = getQueue().remove();
		getQueue().add(task);
		task.step(core, cycles, print);
		if (!task.isAlive())
			getQueue().remove(task);
	}

	/**
	 * This method creates a new tasks and stores it in the core. Its normally
	 * called from during the execution of a spl event.
	 *
	 * @param address
	 *            The address were the new task should start in the core.
	 * @param print
	 *            a writer on witch events can be written.
	 * @param task
	 *            the task, what called spl.
	 * @throws IOException
	 *             could be thrown from the writer.
	 * @throws SyntaxErrorException
	 *             a relict from the constructor. Actually not possible.
	 */
	public void riseANewChild(final Value address, final Writer print,
			final Task task)
			throws IOException, SyntaxErrorException {
		setChildren(getChildren() + 1);
		if (getChildren() >= Constants.CORE_SIZE)
			commitSucide(print, task);
		else
			getQueue().add(new Task(address, getChildren(), this));
	}

	/**
	 * This method kills the program. It get every task from the queue, sort the
	 * tasks along the indexes (low to high), and kills every task. After this
	 * method was executed the queue is empty, every task is killed and for
	 * every task what is killed a event is written.
	 * @param print
	 *            a Writer on witch events could be written
	 * @param task
	 *            The task what caused the call of this method
	 * @throws IOException
	 *             could be thrown by the writer.
	 * @throws SyntaxErrorException
	 *             - a relict from the constructor.
	 */
	private void commitSucide(final Writer print, final Task task)
			throws IOException,
			SyntaxErrorException {
		// HYYYYYAAAAAAAA!!!
		final List<Task> killMe = new ArrayList<Task>(getQueue());
		killMe.add(task);
		Collections.sort(killMe);
		for (final Task suicide : killMe)
			suicide.kill(print);
		getQueue().clear();
		assert !isAlive() : "Program is dead!";
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return getIndex();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object obj) {
		boolean result = true;
		if (obj == null)
			result = false;
		if (getClass() != obj.getClass())
			result = false;
		final Program other = (Program) obj;
		if (children != other.children ||index != other.index || !queue.equals(other.queue))
			result = false;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Program [index=" + index + ", queue=" + queue + ", children="
				+ children + "]";
	}
}
