/* Roman Podolski - r.podolski@web.de, Janek Schoenwetter - janek.schoenwetter@yahoo.com
 * Praktikum Softwareentwicklung II, SS2011
 * Geotelematik und Navigation (GO1b), Hochschule M�nchen
 *   ____
 *  / ___|___  _ __ _____      ____ _ _ __
 * | |   / _ \| '__/ _ \ \ /\ / / _` | '__|
 * | |__| (_) | | |  __/\ V  V / (_| | |
 *  \____\___/|_|  \___| \_/\_/ \__,_|_|
 *
 * Sun Microsystems Inc. Java 1.6.0_24,
 * Windows 7 Enterprise, Windows 7 Starter
 * CANTIA-(Intel(R) Core(TM)2 Duo CPU 2.26GHz, 2267 MHz)
 * ASUS Eee PC (Intel(R) Atom(TM) CPU N550 @ 1,50 GHz)
 */
package corewar.filter.mars;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import corewar.common.constants.Constants;
import corewar.common.constants.GlobalsMARS;
import corewar.common.core.Core;
import corewar.common.exceptions.SyntaxErrorException;
import corewar.common.instruction.Instruction;
import corewar.common.instruction.Value;
import corewar.common.program.Program;
import corewar.filter.NoBlankReader;
import corewar.pipe.decimalcode.Parser;
import corewar.pipe.eventlog.Event;
import corewar.pipe.eventlog.EventType;

/**
 * A Memory Array Redcode Simulator (MARS). "Deimos" is the name of a moon of
 * the planet mars.
 *
 * @author Roman Podolski - r.podolski@web.de, Janek Schoenwetter -
 *         janek.schoenwetter@yahoo.com
 * @version 1.0
 */
public class Deimos implements MarsCore {

	/*
	 * (non-Javadoc)
	 *
	 * @see corewar.filter.mars.MarsCore#runBattle(java.io.Writer,
	 * java.io.Reader[])
	 */
	@Override
	public void runBattle(final Writer protocolWriter,
			final Reader... redcodeReaders) throws IOException {
		final PrintWriter print = new PrintWriter(protocolWriter);
		try {
			final Core core = initCore(print, redcodeReaders);
			final char[] decimalcode = new char[GlobalsMARS.LENGTH_OF_DC_INST];
			final Program[] warriors = new Program[redcodeReaders.length];

			for (int program = 0; program < redcodeReaders.length; program++) {
				final NoBlankReader redcodeReader = new NoBlankReader(
						redcodeReaders[program]);
				final List<Instruction> instStorage = toList(decimalcode,
						redcodeReader);
				warriors[program] = load(core, redcodeReaders.length,
						instStorage, program, print);
			}

			Scheduler.run(core, print, warriors);
		} catch (final SyntaxErrorException e) {
			assert false : "Constructors have been testet and work correctly!";
		}
	}

	/**
	 * This method loads the instructions of a RedCodeProgram on the
	 * MemoryAarrayCode and creates a new Program from this informations.
	 *
	 * @param core
	 *            A MemoryArrayCore on witch the instructions of the Program
	 *            will be stored.
	 * @param programCount
	 *            the Number of Programs total involved in the call of the run
	 *            method.
	 * @param instStor
	 *            A list of the instructions of the Program, what will be stored
	 *            on the core.
	 * @param program
	 *            the Index of the program
	 * @param print
	 *            A writer on witch events will be written.
	 * @throws IOException
	 *             could be thrown by the writer.
	 * @throws SyntaxErrorException
	 *             a relict from the compiler - ignore.
	 * @return A new Program
	 */
	private Program load(final Core core, final int programCount,
			final List<Instruction> instStor, final int program,
			final Writer print) throws IOException,
			SyntaxErrorException {
		final int shootout = generateShootout(programCount, instStor);
		int counter = 0;
		if (instStor.size() > Constants.CORE_SIZE / programCount)
			throw new RuntimeException(
					"Program has to many instructions, "
							+ "to be stored in the Memory Array Core. "
							+ "Consider extending the Coresize or shorten program to run Mars safely.");
		for (final Instruction instruction : instStor) {
			final Value address = new Value(Constants.CORE_SIZE / programCount
					* program + shootout + counter);
			core.load(address, instruction);
			new Event(EventType.Load, program, 0, 0, address, instruction)
					.printEvent(print);
			counter++;
		}
		final Program warrior = new Program(new Value(Constants.CORE_SIZE
				/ programCount * program + shootout), program);
		return warrior;
	}

	/**
	 * Generates a Integer Number what can be used to position programs for a
	 * real simulation in the core. When the system property SHOOTOUT is set
	 * false (default) this method returns 0.
	 * @param programCount
	 *            The number of programs involved.
	 * @param instStor
	 *            A list of the instructions of the Program. The size is used.
	 * @return An integer number, what can be used to position the program in
	 *         the core.
	 */
	private int generateShootout(final int programCount,
			final List<Instruction> instStor) {
		int shootout = 0;
		if (GlobalsMARS.SHOOTOUT) {
			final Random generator = new Random();
			shootout = generator.nextInt(Constants.CORE_SIZE / programCount
					- instStor.size());
		}
		return shootout;
	}

	/**
	 * Creates a List of Instructions from a reader and a Char array.
	 * @param decimalcode
	 *            A char array.
	 * @param redcodeReader
	 *            A Reader
	 * @throws IOException
	 *             could be caused from the reader
	 * @return a List of instructions.
	 */
	private List<Instruction> toList(final char[] decimalcode,
			final Reader redcodeReader) throws IOException {
		final List<Instruction> instStor = new ArrayList<Instruction>();
		// Schleife l�uft �ber Instructionen
		while (redcodeReader.read(decimalcode) != -1)
			instStor.add(Parser.toInstruction(decimalcode));
		return instStor;
	}

	/**
	 * This Factory method creates a new MemoryArrayCore and writes a Init event
	 * on a writer.
	 * @param print
	 *            A writer on witch events can be written.
	 * @param redcodeReaders
	 *            A array with readers.
	 * @return a new MemoryArrayCore
	 * @throws IOException
	 *             could be caused from the writer or a reader.
	 * @throws SyntaxErrorException
	 *             a relict from the compiler.
	 */
	private Core initCore(final Writer print, final Reader... redcodeReaders)
			throws IOException, SyntaxErrorException {
		final Core core = new Core(Constants.CORE_SIZE);
		new Event(EventType.Init, redcodeReaders.length - 1,
				Constants.CORE_SIZE - 1, GlobalsMARS.MAX_CYCLES - 1, new Value(
						Constants.CORE_SIZE - 1), new Instruction())
				.printEvent(print);
		return core;
	}
}
