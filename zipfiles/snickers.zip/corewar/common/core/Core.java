/* Roman Podolski - r.podolski@web.de, Janek Schoenwetter - janek.schoenwetter@yahoo.com
 * Praktikum Softwareentwicklung II, SS2011
 * Geotelematik und Navigation (GO1b), Hochschule M�nchen
 *   ____
 *  / ___|___  _ __ _____      ____ _ _ __
 * | |   / _ \| '__/ _ \ \ /\ / / _` | '__|
 * | |__| (_) | | |  __/\ V  V / (_| | |
 *  \____\___/|_|  \___| \_/\_/ \__,_|_|
 *
 * Sun Microsystems Inc. Java 1.6.0_24,
 * Windows 7 Enterprise, Windows 7 Starter
 * CANTIA-(Intel(R) Core(TM)2 Duo CPU 2.26GHz, 2267 MHz)
 * ASUS Eee PC (Intel(R) Atom(TM) CPU N550 @ 1,50 GHz)
 */
package corewar.common.core;

import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;

import corewar.common.exceptions.SyntaxErrorException;
import corewar.common.instruction.Argument;
import corewar.common.instruction.Command;
import corewar.common.instruction.Instruction;
import corewar.common.instruction.Mode;
import corewar.common.instruction.Value;
import corewar.common.program.Task;
import corewar.pipe.eventlog.Event;
import corewar.pipe.eventlog.EventType;

/**
 * Memory Array Core - The Arena for a corewar.
 * @author Roman Podolski - r.podolski@web.de, Janek Schoenwetter -
 *         janek.schoenwetter@yahoo.com
 * @version 1.0
 */
public class Core {

	/**
	 * An instruction array, in with the fight will be simulated.
	 */
	private final Instruction[] coreArray;

	/**
	 * Public custom constructor. A core is GlobalsMARS.CORESIZE long and
	 * default filled with Dat #0 instructions.
	 * @throws SyntaxErrorException
	 *             Actually this case will never happen - its a relict from the
	 *             default Constructor of Instruction.
	 * @param coresize
	 *            The size/length of the coreArray
	 */
	public Core(final int coresize) throws SyntaxErrorException {
		// TODO parameter rauswerfen, array mit Coresize inizialisieren und
		// Instruction() so modivizieren, das keine Exception mehr geworfen wird
		coreArray = new Instruction[coresize];
		Arrays.fill(coreArray, new Instruction());
	}

	/**
	 * Picks a Instruction from the Core and returns it. If the addressmode of
	 * the Argument is immediate the Method creates a new Dat instruction with
	 * the value of the Argument .Especially important for the Mov command.
	 * @return the wanted Instruction from the coreArray
	 * @throws SyntaxErrorException
	 *             Impossible case - is actually never thrown. Declaration is
	 *             set to safe code - all exception will be caught in the actual
	 *             MARS (Deimos).
	 * @param address
	 *            The argument descriping the address in the corearray. E.g. 2
	 * @param task
	 *            The running task.
	 */
	public Instruction getInstrucion(final Argument address, final Task task)
			throws SyntaxErrorException {
		if (address.getMode() == Mode.immediate)
			return new Instruction(Command.DAT, new Argument(Mode.immediate,
					address.getValue()));
		return getInstrucion(getAddress(address, task));
	}

	/**
	 * Returns a Instruction from the MemoryArrayCore. Returns the actual
	 * instruction, what will be returned in the public method
	 * getInstruction(Argument, Task).
	 * @param address
	 *            A value describing the address of the wanted instruction.
	 * @return A instruction from the corearray.
	 */
	public Instruction getInstrucion(final Value address) {
		return getCoreArray()[address.getArgumentValue()];
	}

	/**
	 * Sets a Instruction on a address in the MemoryArrayCore and writes a
	 * SetMemory Event.
	 * @param address
	 *            The address on which the instruction should be stored.
	 * @param instruction
	 *            The instruction what should be stored in the MemoryArrayCore.
	 * @param print
	 *            the writer on which the SetMemory event is written.
	 * @throws IOException
	 *             if the writer causes a exception.
	 */
	public void set(final Value address, final Instruction instruction,
			final Writer print) throws IOException {
		load(address, instruction);
		new Event(EventType.SetMem, 0, 0, 0, address, instruction)
				.printEvent(print);
	}

	/**
	 * Private getter for the coreArray.
	 * @return the coreArray
	 */
	private Instruction[] getCoreArray() {
		return coreArray;
	}

	/**
	 * Updates the Directionvalue of an Instruction stored on an address in the
	 * memoryArrayCore. This method is especially important for the Add and Djz
	 * commands.
	 * @param address
	 *            The address of the Instruction, what should be modified.
	 * @param inc
	 *            The increment what should be added to the direction value.
	 * @param print
	 *            Writer on with a set memory event is written.
	 * @throws IOException
	 *             if the writer causes an exception.
	 * @throws SyntaxErrorException
	 *             actually not possible - declaration necessary because a new
	 *             Instruction is created.
	 */
	public void update(final Value address, final Value inc, final Writer print)
			throws IOException, SyntaxErrorException {
		final Instruction instruction = new Instruction(getInstrucion(address)
				.getCommand(), getInstrucion(address).getStart(), new Argument(
				getInstrucion(address).getDirection().getMode(), new Value(
						getInstrucion(address).getDirection().getValue()
								.getArgumentValue()
								+ inc.getArgumentValue())));
		set(address, instruction, print);
	}

	/**
	 * Loads an Instruction on the memory array Core without writing an
	 * SetMemory Event.
	 * @param address
	 *            The address on which the instruction should be stored.
	 * @param instruction
	 *            The instruction what should be stored in the MemoryArrayCore.
	 */
	public void load(final Value address, final Instruction instruction) {
		assert instruction != null : "Instruction exsitst!";
		getCoreArray()[address.getArgumentValue()] = instruction;
	}

	/**
	 * Executes the Jmz command in the CoreArray. Is called from JmzCode and
	 * DjzCode.
	 * @param task
	 *            The running task.
	 * @param instruction
	 *            the executed instruction.
	 * @throws SyntaxErrorException
	 *             actually not possible.
	 */
	public void runJmz(final Task task, final Instruction instruction)
			throws SyntaxErrorException {
		if (getValue(instruction.getDirection(), task).getArgumentValue() == 0)
			task.setAddress(new Value(getAddress(instruction.getStart(), task)
					.getArgumentValue() - 1));
	}

	/**
	 * Getter returns a Value from the memoryArrayCore. It checks the
	 * addressmode of the argument and returns the correct Value. This method is
	 * pretty important for the functionality of the whole
	 * MemoryArrayRedcodeSimulator - Especially for Add.
	 * @param argument
	 *            The argument from what a value should be extracted.
	 * @param task
	 *            the running task.
	 * @throws SyntaxErrorException
	 *             actually not possible.
	 * @return a usable value from the MemoryArrayCore.
	 */
	public Value getValue(final Argument argument, final Task task)
			throws SyntaxErrorException {
		final Mode mode = argument.getMode();
		Value result = argument.getValue();
		if (mode != Mode.immediate)
			result = getInstrucion(getAddress(argument, task)).getDirection().getValue();
		return result;
	}

	/**
	 * Returns a value from the MemoryArrayCore - representing a Address. This
	 * method is pretty important for the functionality of the whole MARS.
	 *
	 * @param direction
	 *            The Argument from what the address should be extracted.
	 * @param task
	 *            The Running task.
	 * @throws SyntaxErrorException
	 *             actually not possible
	 * @return a usable Address value.
	 */
	public Value getAddress(final Argument direction, final Task task)
			throws SyntaxErrorException {
		assert direction.getMode() != Mode.immediate : "Addressmode is correct!";
		Value result = new Value(task.getAddress().getArgumentValue()
				+ direction.getValue().getArgumentValue());
		if (Mode.indirect == direction.getMode())
			result = new Value(result.getArgumentValue()
					+ getInstrucion(result).getDirection().getValue()
							.getArgumentValue());
		return result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(coreArray);
		return result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object obj) {
		boolean result = true;
		if (this == obj)
			return true;
		if (obj == null ||getClass() != obj.getClass())
			result = false;
		final Core other = (Core) obj;
		if (!Arrays.equals(coreArray, other.coreArray))
			result = false;
		return result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Core [coreArray=" + Arrays.toString(coreArray) + "]";
	}
}
