/* Roman Podolski - r.podolski@web.de, Janek Schoenwetter - janek.schoenwetter@yahoo.com
 * Praktikum Softwareentwicklung II, SS2011
 * Geotelematik und Navigation (GO1b), Hochschule M�nchen
 *   ____
 *  / ___|___  _ __ _____      ____ _ _ __
 * | |   / _ \| '__/ _ \ \ /\ / / _` | '__|
 * | |__| (_) | | |  __/\ V  V / (_| | |
 *  \____\___/|_|  \___| \_/\_/ \__,_|_|
 *
 * Sun Microsystems Inc. Java 1.6.0_24,
 * Windows 7 Enterprise, Windows 7 Starter
 * CANTIA-(Intel(R) Core(TM)2 Duo CPU 2.26GHz, 2267 MHz)
 * ASUS Eee PC (Intel(R) Atom(TM) CPU N550 @ 1,50 GHz)
 */
package corewar.filter.mars;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import corewar.common.constants.GlobalsMARS;
import corewar.common.core.Core;
import corewar.common.exceptions.SyntaxErrorException;
import corewar.common.instruction.Instruction;
import corewar.common.instruction.Value;
import corewar.common.program.Program;
import corewar.pipe.eventlog.Event;
import corewar.pipe.eventlog.EventType;

/**
 * This is a scheduler for a MemoryArrayRedCodeSimulator.
 * @author Roman Podolski - r.podolski@web.de, Janek Schoenwetter -
 *         janek.schoenwetter@yahoo.com
 * @version 1.0
 */
public final class Scheduler {

	/**
	 * Blocked private constructor.
	 */
	private Scheduler() {
		assert false : "Utility class without instances!";
	}

	/**
	 * This method runs executions of a Corewar battle in the right order.
	 * @param core
	 *            a MemoryArrayCore
	 * @param print
	 *            a Writer
	 * @param warriors
	 *            A Array with the programs in the core.
	 * @throws SyntaxErrorException
	 *             a relict from the compiler - actually not possible
	 * @throws IOException
	 *             could be thrown from the writer.
	 */
	static void run(final Core core, final Writer print,
			final Program... warriors) throws SyntaxErrorException, IOException {
		if(GlobalsMARS.MAX_CYCLES == 0)
			assert false : "more than one repition!";
		int cycles = 0;
		while (stillStanding(warriors).size() > 1
				&& cycles < GlobalsMARS.MAX_CYCLES) {
			for (final Program warrior : warriors)
				warrior.step(core, cycles, print);
			cycles++;
		}
		if (stillStanding(warriors).size() == 1)
			new Event(EventType.Win, stillStanding(warriors).get(0).getIndex(),
					0, 0, new Value(0), new Instruction()).printEvent(print);
		else if (cycles >= GlobalsMARS.MAX_CYCLES
				|| stillStanding(warriors) == null)
			new Event(EventType.Win, warriors.length, 0, 0, new Value(0),
					new Instruction()).printEvent(print);
	}

	/**
	 * Getter for all still executable programs.
	 * @param warriors
	 *            A Array with programs.
	 * @return A list with all still executable programs.
	 */
	private static List<Program> stillStanding(final Program[] warriors) {
		final List<Program> stillStanding = new ArrayList<Program>();
		for (final Program warrior : warriors)
			if (warrior.isAlive())
				stillStanding.add(warrior);
		return stillStanding;
	}
}
