/* Roman Podolski - r.podolski@web.de, Janek Schoenwetter - janek.schoenwetter@yahoo.com
 * Praktikum Softwareentwicklung II, SS2011
 * Geotelematik und Navigation (GO1b), Hochschule M�nchen
 *   ____
 *  / ___|___  _ __ _____      ____ _ _ __
 * | |   / _ \| '__/ _ \ \ /\ / / _` | '__|
 * | |__| (_) | | |  __/\ V  V / (_| | |
 *  \____\___/|_|  \___| \_/\_/ \__,_|_|
 *
 * Sun Microsystems Inc. Java 1.6.0_24,
 * Windows 7 Enterprise, Windows 7 Starter
 * CANTIA-(Intel(R) Core(TM)2 Duo CPU 2.26GHz, 2267 MHz)
 * ASUS Eee PC (Intel(R) Atom(TM) CPU N550 @ 1,50 GHz)
 */
package corewar.filter;

import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;

/**
 * A reader witch only reads characters, no whitespace.
 * @author Roman Podolski - r.podolski@web.de, Jannek Schoenwetter -
 *         janek.schoenwetter@yahoo.com
 * @version 1.0
 */
public class NoBlankReader extends FilterReader {

	/**
	 * Custom constructor.
	 * @param reader
	 *            A reader.
	 */
	public NoBlankReader(final Reader reader) {
		super(reader);
	}

	@Override
	public int read() throws IOException {
		int withespace = 0;
		withespace = super.read();
		while (Character.isWhitespace(withespace))
			withespace = super.read();
		return withespace;
	}

	@Override
	public int read(final char[] line) throws IOException {
		int character = -1;
		for (int i = 0; i < line.length; i++) {
			character = read();
			line[i] = (char) character;
		}
		return character;
	}
}
